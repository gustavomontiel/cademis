#!/bin/bash 
sudo docker-compose up -d

sudo docker exec -i -tcademisapp composer install
sudo docker exec -i -t cademisapp composer dump-autoload

sudo docker exec cademisapp php -S cademisapp:8000 -t ./public
